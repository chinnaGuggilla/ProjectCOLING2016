//====fgfgfgfg
$(".go-top").hide();
var menu_open = false;
setTimeout(function(){ jQuery("#wrapper").hide(); }, 4000);
jQuery(".closedd").click(function(){
   jQuery("#wrapper").hide(); 
});

jQuery(function(){
	jQuery("#mytest").click(function(){
        jQuery("#toggle_hide_menu").toggle();
    });
	jQuery('.nav-main-menu > ul').clone().appendTo('.menu-toggle-menu-container');
	
	jQuery('.toggle-menu-button').click(function(){
		if(menu_open == false){
			jQuery("#main-menu-toggle").addClass("toggle-menu-open");
			jQuery("#page").addClass("page-to-right");
			menu_open = true;
		}else{
			jQuery("#main-menu-toggle").removeClass("toggle-menu-open");
			jQuery("#page").removeClass("page-to-right");
			menu_open = false;
		}
	});
	
	jQuery('.toggle-menu-close').click(function(){
		if(menu_open == true){
			jQuery("#main-menu-toggle").removeClass("toggle-menu-open");
			jQuery("#page").removeClass("page-to-right");
			menu_open = false;
		}
	});
	
	
	//Related post
	jQuery('.post-relative-column').last().addClass('column-last');
	
	
	//Set background
	jQuery('.background-url').each(function(){
		$val = jQuery(this).attr('data-bg-img');
		jQuery('.index-box-promote').css("background-image","url("+$val+")");
	});
	
	
	
	//blogs list
	jQuery('.video-url').each(function(){
		$val = jQuery(this).attr('data-url');
		jQuery(this).html("<iframe width='560' height='315' src='"+ $val +"' frameborder='0' allowfullscreen></iframe>");
	});
	jQuery('.audio-url').each(function(){
		$val = jQuery(this).attr('data-url');
		jQuery(this).html("<iframe width='100%' height='450' scrolling='no' frameborder='no' src='"+ $val +"'></iframe>");
	});
	jQuery('.post-map-container').each(function(){
		$val = jQuery(this).attr('data-url');
		jQuery(this).html("<iframe src='"+ $val +"' width='400' height='300' frameborder='0' style='border:0'></iframe>");
	});
	
	jQuery('.form-item-copy').remove();
	
	
	//pager
	jQuery('ul.pager').addClass('paginate');
	jQuery('ul.pager li').addClass('page-numbers');
	jQuery('ul.pager li.pager-current').addClass('current');
	
	
	//comment
	jQuery('.comment-form .filter-wrapper.form-wrapper').remove();
	jQuery('.comment-form #edit-preview').remove();
	jQuery('.comment-form').addClass('content');	
	
	
	//404
	jQuery('.error404 input[type=text]').removeAttr('size');
	jQuery('#search-form').addClass('content');
	
	
	//taxonomy
	jQuery('.term-listing-heading').remove();
	
	//form
	jQuery('form').addClass('content');
	jQuery('.button-operator').remove();
	
	
});

	jQuery(".toptog1").click(function(){
				jQuery(".togdrp").toggle();
                $('.trnndddp2').hide();
                $('#panel-menu23').hide();
                $('#panel-menu22').hide();
                $("#panel2").hide();
	});
	
	jQuery('.trendingblk').click(function(){
		$('.trnndddp2').toggle();
        jQuery(".togdrp").hide();
        $('#panel-menu23').hide();
        $('#panel-menu22').hide();
        $("#panel2").hide();
	});
$('#flip-mainres22').click(function(){
  
  $('#panel-menu22').slideToggle();
  $('#panel-menu23').hide();
  $('.trnndddp2').hide();
  jQuery(".togdrp").hide();
  $("#panel2").hide();
  });

$(document).ready(function(){
    $('#filter').change(function() {
		var fVal = $(this).val();
		if(fVal == "institutes") {
			window.location = "/mba-bschool-insts-notification.php";
		} 
		else if(fVal == "all") {
			window.location = "/Info/mba-bschool-notification.php";
		}
		else if(fVal == "tests") {
			window.location = "/mba-bschool-tests-notification.php";
		}
	});
    $('#filter_admission').change(function() {
		var fVals = $(this).val();
		if(fVals == "institutes") {
			window.location = "/info/comprehensive-listing-institutes.php";
		} 
		else if(fVals == "all") {
			window.location = "/info/admission-alerts.php";
		}
		else if(fVals == "tests") {
			window.location = "/info/comprehensive-listing-tests.php";
		}
	});
    $('#filter_a_com').change(function() {
		var sVal = $(this).val();
		var fVal = $("#filter_a_com").val();
		window.location = "/info/comprehensive-listing-institutes.php?sort="+sVal+"&filter="+fVal;
	});
    $('#filter_a_test').change(function() {
		var sVal = $(this).val();
		var fVal = $("#filter_a_test").val();
		window.location = "/info/comprehensive-listing-tests.php?sort="+sVal+"&filter="+fVal;
	});
    $('#sort_a_test').change(function() {
		var fVal = $("#filter").val();
		 window.location = "/info/comprehensive-listing-tests.php?sort="+$(this).val()+"&filter="+fVal;
	});
    $('#sor_a_comp').change(function() {
		var fVal = $("#filter_a_com").val();
		window.location = "/info/comprehensive-listing-institutes.php?sort="+$(this).val()+"&filter="+fVal;
	});
    $('#sortall').change(function() {
        //alert("sdfa");
		window.location = "/Info/mba-bschool-notification.php?sort="+$(this).val();
	});
    $('#sorttest').change(function() {
        //alert("sdfa");
		window.location = "/mba-bschool-tests-notification.php?sort="+$(this).val();
	});
    $('#sortinst').change(function() {
        //alert("sdfa");
		window.location = "/mba-bschool-insts-notification.php?sort="+$(this).val();
	});
    $('#sort_adm').change(function() {
        //alert("sdfa");
		window.location = "/info/admission-alerts.php?sort="+$(this).val();
	});
var cookiVal = readCookie('starrate');
	if(cookiVal == $("#pageid").val())	{
	}
	else
	{
		setTimeout(function() { 
		$("#overlay-back").fadeIn(1200,function(){
			$('#popup1').show();	
		}); 
		}, 2500000)	
		//$('#overlay-back').fadeIn(900,function(){ $('#popup1').show();		
		//});	
	}			
	$("#dontremovethisid").on("click",function(){		
		if(cookiVal == $("#pageid").val())		{			
			$('#overlay-back').fadeIn(900,function(){				
			$('#popupalready').show();			
			});		
		}		
		else		 
		{			
			$('#overlay-back').fadeIn(900,function(){				
				$('#popup1').show();			
			});		
		}	
	})			
	$("#close-image").on('click', function() {	
		$('#popup1').hide();
		$('#overlay-back').fadeOut(500);
		
	});	
	$("#close-imageA").on('click', function() {	
		$('#popupalready').hide();		
		$('#overlay-back').fadeOut(500);	
	});
	});
	function highlightStar(obj,id) {
		removeHighlight(id);
		$('.demo-table #tutorial-'+id+' li').each(function(index) {		
			$(this).addClass('highlight');		
			if(index == $('.demo-table #tutorial-'+id+' li').index(obj)) {			
				return false;			
			}	
		});
	}
	function removeHighlight(id) {	
		$('.demo-table #tutorial-'+id+' li').removeClass('selected');	
		$('.demo-table #tutorial-'+id+' li').removeClass('highlight');
	}
	function CountRating(obj,id) {	
		$('.demo-table #tutorial-'+id+' li').each(function(index) {		
			$(this).addClass('selected');		
			$('#tutorial-'+id+' #rating').val((index+1));		
			if(index == $('.demo-table #tutorial-'+id+' li').index(obj)) {
				return false;			
			}	
		});
	}
	function addRating(id) {
		var CurRate = $('#rating').val();	
		$.ajax({		
			url: Drupal.settings.basePath + 'admin/sidebar-bullseye/rating',		
			type: "POST",		
			data:'id='+id+'&rating='+CurRate,
			dataType: 'html',
			beforeSend: function() {              
			$(".UpdateStar").html('updating...');        
			},		success: function(data, textStatus, jQxhr) {
				
			 var ndata = jQuery.parseJSON(data);
			 console.log(ndata);
			$(".UpdateStar").html(ndata.message);			
			$(".UpdateStar").fadeIn('slow');			
			$(".UpdateStar").fadeIn(2000);						
			$('#popup1').hide();			
			$('#overlay-back').fadeOut(500);						
			createCookie('starrate',id,7);			
			//window.location.reload();		
			}	
		});
	}
	function resetRating(id) {	
		if($('#tutorial-'+id+' #rating').val() != 0) 
		{		
			$('.demo-table #tutorial-'+id+' li').each(function(index) {			
				$(this).addClass('selected');			
				if((index+1) == $('#tutorial-'+id+' #rating').val()) {				
					return false;				
				}		
			});	
		}
	}

	function createCookie(name,value,days) {    
		if (days) {        
			var date = new Date();        
			date.setTime(date.getTime()+(days*24*60*60*1000));        
			var expires = "; expires="+date.toGMTString();    
		}    
		else var expires = "";    
	document.cookie = name+"="+value+expires+"; path=/";
	}
	function readCookie(name) {    
		var nameEQ = name + "=";    
		var ca = document.cookie.split(';');    
		for(var i=0;i < ca.length;i++) {        
			var c = ca[i];        
			while (c.charAt(0)==' ') c = c.substring(1,c.length);        
				if (c.indexOf(nameEQ) == 0) 
					return c.substring(nameEQ.length,c.length);    
		}    
		return null;
	}  
	
$('#flip-mainres23').click(function(){
$('#flip-mainres23 span img').toggleClass('reverse');
});
$('#flip-mainres23').click(function(){
  
  $('#panel-menu23').slideToggle();
  $('#panel-menu22').hide();
  $('.trnndddp2').hide();
  jQuery(".togdrp").hide();
  $("#panel2").hide();
  });

$("#flip2").click(function(){
			$("#panel2").slideToggle(300);
            $('#panel-menu23').hide();
  $('#panel-menu22').hide();
  $('.trnndddp2').hide();
  jQuery(".togdrp").hide();
		});
 $("#container").css("display", "block");
$("#content").css("display", "block");       
        
    