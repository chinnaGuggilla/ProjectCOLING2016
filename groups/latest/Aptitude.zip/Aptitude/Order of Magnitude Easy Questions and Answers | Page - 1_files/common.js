function displayImage(input) {
	if (input.files && input.files[0]) {
        var reader = new FileReader();
        var divId = input.id + "_display";
		reader.onload = function (e) {
        $('#'+divId).attr('src', e.target.result);};
		reader.readAsDataURL(input.files[0]);
    }
}

function getChildTopics(topicValue,selectBoxId) {
	var selectList = $('#'+selectBoxId);
    selectList.find("option:gt(0)").remove();
	$data = {'topic':topicValue};
    $.ajax({
        type: 'POST',
        url: 'https://'+window.location.hostname+'/admin/topic-service/get-child-topic', 
        data: $data,
        dataType: "text",  
        cache:false,
        success:function(data){
            var $topics = JSON.parse(data);
			for (var topicId in $topics) {
				$('#'+selectBoxId).append($('<option>', {value: topicId, text:  $topics[topicId]}));
			}
        }
    });
    return false;
}

function displaySuccessMsg(successMsg){
	$('#error_msg').hide("slow");
	$('#success_msg').html('<strong>Success! </strong>'+successMsg);
	$('#success_msg').show("slow");
}
function displayErrorMsg(errorMsg){
	$('#success_msg').hide("slow");
	$('#error_msg').html('<strong>Error! </strong>'+errorMsg);
	$('#error_msg').show("slow");
}