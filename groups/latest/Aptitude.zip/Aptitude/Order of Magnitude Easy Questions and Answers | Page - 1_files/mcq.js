function performToggle(divId, questionNumber) {
    if(divId !=='hint'){
		$("#hint-"+questionNumber).hide("slow");
	}
	if(divId !=='answer'){
		$("#answer-"+questionNumber).hide("slow");
	}
	//if(divId !=='workspace'){
	//	$("#workspace-"+questionNumber).hide("slow");
	//}
	if(divId !=='report'){
		$("#report-"+questionNumber).hide("slow");
	}
	
	jQuery("#"+divId+"-"+questionNumber).toggle("slow");
    
}